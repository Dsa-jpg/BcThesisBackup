<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="cs_CZ">
    <context>
        <name>behavior_1/behavior.xar:/Animated Say</name>
        <message>
            <source>Ahoj</source>
            <comment>Text</comment>
            <translation type="vanished">Ahoj</translation>
        </message>
        <message>
            <source>Povídej</source>
            <comment>Text</comment>
            <translation type="obsolete">Povídej</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say</name>
        <message>
            <source>Ahoj</source>
            <comment>Text</comment>
            <translation type="vanished">Ahoj</translation>
        </message>
        <message>
            <source>Nerozuměl jsme zopakuj to ještě jednou.</source>
            <comment>Text</comment>
            <translation type="obsolete">Nerozuměl jsme zopakuj to ještě jednou.</translation>
        </message>
        <message>
            <source>Nerozuměl jsem zopakuj to ještě jednou.</source>
            <comment>Text</comment>
            <translation type="obsolete">Nerozuměl jsem zopakuj to ještě jednou.</translation>
        </message>
        <message>
            <source>Nerozuměl jsem zkus to znovu.</source>
            <comment>Text</comment>
            <translation type="obsolete">Nerozuměl jsem zkus to znovu.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Povídej</source>
            <comment>Text</comment>
            <translation type="unfinished">Povídej</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (1)</name>
        <message>
            <source>Ahoj</source>
            <comment>Text</comment>
            <translation type="vanished">Ahoj</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Ještě?</source>
            <comment>Text</comment>
            <translation type="unfinished">Ještě?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (2)</name>
        <message>
            <source>Kde jsi?</source>
            <comment>Text</comment>
            <translation type="obsolete">Kde jsi?</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Už jdu.</source>
            <comment>Text</comment>
            <translation type="unfinished">Už jdu.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (3)</name>
        <message>
            <source>Už jsem u tebe.</source>
            <comment>Text</comment>
            <translation type="obsolete">Už jsem u tebe.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Jsem tu.</source>
            <comment>Text</comment>
            <translation type="unfinished">Jsem tu.</translation>
        </message>
    </context>
</TS>
